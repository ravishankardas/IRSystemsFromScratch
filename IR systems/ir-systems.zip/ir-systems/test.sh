python3 final_bm25.py $1
echo bm25 done
python3 final_brs.py $1
echo brs done
python3 final_tfidf.py $1
echo tfidf done
