#!/usr/bin/env python
# coding: utf-8

# In[40]:


#importing all the necessary libraries
import pickle
from nltk.tokenize import word_tokenize
import re
import os
from nltk.corpus import stopwords
import numpy as np
import sys
import nltk
from num2words import num2words
from math import *
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
import pandas as pd
import numpy as np


# In[ ]:

#function to change directories
def dirback():
    m = os.getcwd()
    n = m.rfind("/")
    d = m[0: n+1]
    os.chdir(d)
    return None


# In[ ]:

nltk.download('punkt')
nltk.download('stopwords')
dirback()
path = os.getcwd()


# In[41]:


#this dictionary will store the query text as key and queryid as their value
query_list = {}
file_name = sys.argv[1]
file_name+=".txt"

query = open(file_name,'r')


# In[42]:


#every item consists of two words seprated by a tab character so we split it
for q in query:
    new_text = q.split("\t")
    query_list[new_text[1].replace("\n","")] = new_text[0].replace("\n", "")


# In[43]:


#useful for stemming and removing stopwords
obj=PorterStemmer()
stop_words=set(stopwords.words('english'))


# In[44]:


# this function will preprocess the querytext and perform operations like 
# tokenization , stemming , removing non-ascii characters making characters lowercase and removing all the single
# length digits
def preprocess(querytext):
    text=str(np.char.lower(querytext))
    new_text = re.sub(r'[^\w\s]',' ',text)
    token_list=word_tokenize(new_text)
    word_list=token_list
    for ind,word in enumerate(word_list):
        if word.isdigit() and len(word)<4:
            word_list[ind]=num2words(int(word))

    word_list=' '.join(word_list)
    word_list=re.sub(r'[^\w\s]',' ',word_list)
    word_list=word_tokenize(word_list)
    word_list=[word for word in word_list if word not in stop_words]
    new_words=list(filter(lambda x:len(x)>1,word_list))
    stem_words=[obj.stem(word) for word in new_words]
    return stem_words


# In[45]:


#opening all the required pickle files for faster query processing

#this file has the number of document the word is present in
file=open('posting_lists',"rb")
posting_lists=pickle.load(file)

#this file has the filenames and the number of words in it
file=open('file_index','rb')
file_index=pickle.load(file)

#this file has different unique words in every document
file=open("file_word_list",'rb')
file_words=pickle.load(file)

#set containing all the unique words in whole of the corpus
master_unique_words=set(posting_lists.keys())


# In[46]:


#in master_list we will store the top relevent document names corresponding to every querytext
#in rel_lits we will store the relevency according to everty querytext and extracted documents
master_list = {}
rel_list = {}
for k,v in query_list.items():
    master_list[k]=[]
    rel_list[k]=[]


# In[47]:


#here we are iterating through every word(querytext) from the quer_list and finding the corresponding bm25 score 
#and saving the extracted files in master_list
for key,value in query_list.items():
    query_text=key
    words = preprocess(query_text)
    


    #query_words=[words[0]]

    #here we are adding the AND opeartors between the words in the querytext
    new_str = ""
    for i in range(len(words)):
        if(i==len(words)-1):
            new_str+=words[i]
        else:
            new_str+=words[i]
            new_str+=" and "
    query_words = list(new_str.split(" "))

    operators=[] 
    non_operators=[] #this list will contain words other than the operators

    for word in query_words:
        value = word.lower()
        if value == "and" or value == "or":
            operators.append(value)
        else:
            non_operators.append(value)
    
    stemmed_non_operators=[obj.stem(word) for word in non_operators]#performing stemming on the query words

    tot_doc_size=len(file_index)
    vector=[]
    word_matrix=[]
    
    
    #here we are making a vector of zeroes of the query size and updating the vector if that word is present in 
    # the posting list
    for word in stemmed_non_operators:
        vector=[0]*tot_doc_size
        if word in master_unique_words:
            for w in posting_lists[word].keys():
                vector[w]=1
        word_matrix.append(vector)
    
    # here we are taking the first two vectors and performing the operaion(AND or OR) and storing on the top matrix
    # so that we can do the same with the updated vector with the next vector(3rd in line)
    matrix = word_matrix
    for op in operators:
        first_vector=word_matrix[0]
        second_vector=word_matrix[1]
        output=[] 
        for a,b in zip(first_vector,second_vector):
            output.append(a&b)
        matrix = matrix[2:]       
        matrix.insert(0,output)

        word_matrix=matrix

    cnt=0
    
    
    #after the above loop is done we take the top vector and check if the bit at that position is set we take take
    #that docuement and store
    final_vector = word_matrix[0]
    for bit in final_vector:
        
        
        if bit==1:
            master_list[key].append(file_index[cnt][0])
            rel_list[query_text].append(1)
        else:
            rel_list[query_text].append(0)
        cnt+=1
        


# In[48]:


#here we are making the dataframe with the format and it will be filled with the above extracted files from
#updated master_list for every query
df = pd.DataFrame(columns=['queryid','iteration','docid','relevence'])


# In[49]:


final_list = []
the_list = []
for i in range(4):
    the_list.append([])


# In[50]:


for k,v, in query_list.items():
    docid = v
    ind = 0
    for doc_name in master_list[k]:
        the_list[0].append(v)
        the_list[1].append(1)
        the_list[2].append(doc_name.split('.')[0])
        the_list[3].append(rel_list[k][ind])


# In[51]:


df['queryid'] = the_list[0]
df['iteration'] = the_list[1]
df['docid'] = the_list[2]
df['relevence'] = the_list[3]


# In[52]:


new_df = df.copy(deep=True)


# In[54]:


#since there is no notion of score in boolean retrieval method we are taking the top 10 documents for every unique
#queyid in the above dataframe
all_dfs = []
for i in new_df['queryid'].unique():
    x = new_df[new_df['queryid']==i].head(5)
    all_dfs.append(x)


# In[55]:


for df in all_dfs:
    df.columns = ['queryid','iteration','docid','relevence']


# In[56]:

os.chdir(path)
fin_df = pd.concat(all_dfs).reset_index(drop=True)
fin_df.to_csv('QRels_brs.csv',index=False)

