#!/usr/bin/env python
# coding: utf-8

# In[1]:


#importing all the necessary libraries
import pickle
from nltk.tokenize import word_tokenize
import re
import os
import sys
import nltk
from nltk.corpus import stopwords
import numpy as np
from num2words import num2words
from math import *
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
import pandas as pd
import numpy as np


# In[ ]:

#function to change directories
def dirback():
    m = os.getcwd()
    n = m.rfind("/")
    d = m[0: n+1]
    os.chdir(d)
    return None


# In[ ]:

nltk.download('punkt')
nltk.download('stopwords')
dirback()
path = os.getcwd()

# In[2]:


#this dictionary will store the query text as key and queryid as their value
query_list = {}
file_name = sys.argv[1]
file_name+=".txt"

query = open(file_name,'r')


# In[3]:


#every item consists of two words seprated by a tab character so we split it
for q in query:
    new_text = q.split("\t")
    query_list[new_text[1].replace("\n","")] = new_text[0].replace("\n", "")


# In[4]:


#useful for stemming and removing stopwords
obj=PorterStemmer()
stop_words=set(stopwords.words('english'))


# In[5]:


# this function will preprocess the querytext and perform operations like 
# tokenization , stemming , removing non-ascii characters making characters lowercase and removing all the single
# length digits
def preprocess(querytext):
    text=str(np.char.lower(querytext))
    new_text = re.sub(r'[^\w\s]',' ',text)
    token_list=word_tokenize(new_text)
    word_list=token_list
    for ind,word in enumerate(word_list):
        if word.isdigit() and len(word)<4:
            word_list[ind]=num2words(int(word))

    word_list=' '.join(word_list)
    word_list=re.sub(r'[^\w\s]',' ',word_list)
    word_list=word_tokenize(word_list)
    word_list=[word for word in word_list if word not in stop_words]
    new_words=list(filter(lambda x:len(x)>1,word_list))
    stem_words=[obj.stem(word) for word in new_words]
    return stem_words


# In[6]:


#opening all the required pickle files for faster query processing


#this file has the number of document the word is present in
file=open('posting_lists',"rb")
posting_lists=pickle.load(file)
master_unique_words=set(posting_lists.keys())

#this file has the filenames and the number of words in it
file=open('file_index','rb')
file_index=pickle.load(file)

#this file has different unique words in every document
file=open("file_word_list",'rb')
file_words=pickle.load(file)

#this file contains the norms of all document
file=open("file_norms","rb")
file_norms=pickle.load(file)


# In[7]:


#this function finds the term frequency(tf) and the inverse document frequency(idf) and returns the product
# where tf is the number of repetetions of a word and idf is the log of the ration between total document size
# and number of documents containing that word. we are adding the one for numerical stability 

def get_tfIDF(word,filename):
    idf=np.log((total_docs_size+1)/(len(posting_lists[word])+1))
    freq=0
    if filename in posting_lists[word].keys():   
        freq=posting_lists[word][filename]
    tf_idf_val=idf*freq
    
    return tf_idf_val


# In[8]:


#in master_list we will store the top relevent document names corresponding to every querytext
#in rel_lits we will store the relevency according to everty querytext and extracted documents
master_list = {}
rel_list = {}
for k,v in query_list.items():
    master_list[k]=[]
    rel_list[k]=[]


# In[9]:


#here we are iterating through every word(querytext) and finding the corresponding bm25 score and saving the extracted
# files in master_list
for key,value in query_list.items():
    query_text=key
    final_stem_words = preprocess(query_text)
    total_docs_size=len(file_index)
    

    query_vocab=list(set(final_stem_words))
    query_vector=np.zeros(len(query_vocab))
    
    #here we are calculating the tfidf for every word in the querytext
    for word in query_vocab:
        term_freq=0
        for it in final_stem_words:
            if it==word:
                term_freq+=1
        num=0
        if word in master_unique_words:
            num = len(posting_lists[word])

        idf=np.log2((total_docs_size+1)/(num+1))
        idx = -1
        for itr in range(len(query_vocab)):
            if query_vocab[itr] == word:
                idx=itr
                break

        query_vector[idx]=term_freq*idf
        
    query_vector=query_vector/np.linalg.norm(query_vector)
    
    # here we will set the bit if that word is present in the corpus and in the querytext and will divide with the
    #file norms for that corresponding filename
    document_vector={}
    for file_idx in file_index.keys():
        document_vector[file_idx]=np.zeros(len(query_vocab))
        for word in query_vocab:
            if word in master_unique_words:
                idx = -1
                for itr in range(len(query_vocab)):
                    if query_vocab[itr] == word:
                        idx=itr
                        break

                document_vector[file_idx][idx]=get_tfIDF(word,file_idx)
        doc_vectors_norm=file_norms[file_idx]
        document_vector[file_idx]/=doc_vectors_norm
    
    #here we will calculate the cosine similarity score by doing a dot product between the query vector
    #document vector
    cosine_similarity={}

    for value1 in document_vector.keys():
        cosine_similarity[value1]=np.dot(document_vector[value1],query_vector)

    cosine_similarity=sorted(cosine_similarity.items(),key=lambda x:x[1],reverse=True)
    cnt=5
    for i in range(len(file_index)):
        value2=cosine_similarity[i][0]
        if cnt==0:
            break
        cnt-=1
        master_list[key].append(file_index[value2][0])
        if value2 == 0:
            rel_list[query_text].append(0)
        else:
            rel_list[query_text].append(1)


# In[12]:


#here we are making the dataframe with the format and it will be filled with the above extracted files from
#updated master_list for every query
df = pd.DataFrame(columns=['queryid','iteration','docid','relevence'])


# In[13]:


final_list = []
the_list = []
for i in range(4):
    the_list.append([])


# In[14]:


for k,v, in query_list.items():
    docid = v
    ind = 0
    for doc_name in master_list[k]:
        the_list[0].append(v)
        the_list[1].append(1)
        the_list[2].append(doc_name.split('.')[0])
        the_list[3].append(rel_list[k][ind])


# In[15]:


df['queryid'] = the_list[0]
df['iteration'] = the_list[1]
df['docid'] = the_list[2]
df['relevence'] = the_list[3]


# In[16]:

os.chdir(path)
df.to_csv('QRels_tfidf.csv',index=False)

