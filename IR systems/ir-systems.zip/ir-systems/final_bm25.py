#!/usr/bin/env python
# coding: utf-8

# In[1]:


#importing all the necessary libraries
import pickle
from nltk.tokenize import word_tokenize
import re
import os
import nltk
from nltk.corpus import stopwords
import numpy as np
import sys
from num2words import num2words
import math
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
import pandas as pd
import numpy as np


# In[ ]:

#function to change directories
def dirback():
    m = os.getcwd()
    n = m.rfind("/")
    d = m[0: n+1]
    os.chdir(d)
    return None


# In[ ]:

nltk.download('punkt')
nltk.download('stopwords')
dirback()
path=os.getcwd()


# In[2]:


#this dictionary will store the query text as key and queryid as their value
query_list = {}
file_name = sys.argv[1]
file_name+=".txt"

query = open(file_name,'r')


# In[3]:


#every item consists of two words seprated by a tab character so we split it
for q in query:
    new_text = q.split("\t")
    query_list[new_text[1].replace("\n","")] = new_text[0].replace("\n", "")


# In[4]:


#useful for stemming and removing stopwords
obj=PorterStemmer()
stop_words=set(stopwords.words('english'))


# In[5]:


# this function will preprocess the querytext and perform operations like 
# tokenization , stemming , removing non-ascii characters making characters lowercase and removing all the single
# length digits
def preprocess(querytext):
    text=str(np.char.lower(querytext))
    new_text = re.sub(r'[^\w\s]',' ',text)
    token_list=word_tokenize(new_text)
    word_list=token_list
    for ind,word in enumerate(word_list):
        if word.isdigit() and len(word)<4:
            word_list[ind]=num2words(int(word))

    word_list=' '.join(word_list)
    word_list=re.sub(r'[^\w\s]',' ',word_list)
    word_list=word_tokenize(word_list)
    word_list=[word for word in word_list if word not in stop_words]
    new_words=list(filter(lambda x:len(x)>1,word_list))
    stem_words=[obj.stem(word) for word in new_words]
    return stem_words


# In[6]:


#opening all the required pickle files for faster query processing


file=open('posting_lists',"rb")
#this file has the number of document the word is present in
posting_lists=pickle.load(file)

#this file has the filenames and the number of words in it
file=open('file_index','rb')
file_index=pickle.load(file)

#this file has different unique words in every document
file=open("file_word_list",'rb')
file_words=pickle.load(file)
total_docs_size=len(file_index)

#hyperparameters useful for finding the bm25 score
k = 1.2
b = 0.75


# In[7]:


#in master_list we will store the top relevent document names corresponding to every querytext
#in rel_lits we will store the relevency according to everty querytext and extracted documents
master_list = {}
rel_list = {}
for k,v in query_list.items():
    master_list[k]=[]
    rel_list[k]=[]


# $\text{BM25 score for a document is given by: }$\
# $score(D,Q) = \sum_{i=1}^nidf(q_i).\bigg(\frac{f(q_i,D).(k+1)}{f(q_i,D)+k.\big(1-b+b.\frac{|D|}{avgdl}\big)}+1\bigg)$\
# $where: $\
# $score(D,Q):\text{BM25 score for document } D \text{ for query }Q$\
# $f(q_i,D):\text{term frequency of }(q_i)\text{ in document}D$\
# $|D|:\text{number of words in document D}$\
# $avgdl:\text{average length of documents}$

# $\text{Calculating inverse document frequency for the above BM25 score}$\
# $idf(q_i) = log\big(\frac{N-n(q_i)+0.5}{n(q_i)+0.5}+1\big)$\
# $where :$\
# $idf(q_i):\text{inverse document frequency of query }(q_i)$\
# $N:\text{Number of documents}$\
# $n(q_i):\text{number of documents containing }(q_i)$

# In[3]:


#here we are iterating through every word(querytext) and finding the corresponding bm25 score and saving the extracted
# files in master_list
for key,value in query_list.items():
    query_text=key
    final_stem_words = preprocess(query_text)
    total_docs_size=len(file_index)
    


    total_words = 0
    for k,v in file_index.items():
        total_words+=v[1]
    
    l_avg = total_words/total_docs_size
    N = len(file_index)
    scores = {}#this dict will store all the scores corresponding to their word,document 
    
    # in this loop we are using the above formula to find the bm25 score for all the words in a querytext and 
    # then storing the extracted files in the above made maser_list dictionary
    # for relevency if the bm25 score is zero we are assigning 0 otherwise 1
    for i in range(N):
        scores[i]=0
        for word in final_stem_words:
            tf=0
            doc_length = len(file_words[i])
            if word in posting_lists:
                if i in posting_lists[word]:
                    tf=posting_lists[word][i]
            df=0
            if word in file_words[i]:
                df = len(posting_lists[word])
            idf=math.log(1+(N-df+0.5)/(df+0.5))
            num = idf * tf * (k+1)
            den = tf + k*(1-b+b*(doc_length/l_avg))
            bm25_score=num/den
            scores[i]+=bm25_score  



    final_score = {}
    relevence = []
    for i in scores:
        final_score[file_index[i][0]]=scores[i]
        
    #here we are sorting so to extract the top 10 relevent documents
    final_score = sorted(final_score.items(),key=lambda x:x[1],reverse=True)


    cnt=5
    for i in final_score:
        if cnt==0:
            break
        cnt-=1
        txt = i[0].split(".")[0]
        if i[1] == 0:
            rel_list[key].append(0)
        else:
            rel_list[key].append(1)
        master_list[key].append(txt)


# In[9]:


#here we are making the dataframe with the format and it will be filled with the above extracted files from
#updated master_list for every query
df = pd.DataFrame(columns=['queryid','iteration','docid','relevence'])


# In[10]:


# final_list = []
the_list = []
for i in range(4):
    the_list.append([])      


# In[11]:


for k,v, in query_list.items():
    docid = v
    ind = 0
    for doc_name in master_list[k]:
        the_list[0].append(v)
        the_list[1].append(1)
        the_list[2].append(doc_name)
        the_list[3].append(rel_list[k][ind])
        ind+=1


# In[12]:


df['queryid'] = the_list[0]
df['iteration'] = the_list[1]
df['docid'] = the_list[2]
df['relevence'] = the_list[3]


# In[13]:

os.chdir(path)
df.to_csv('QRels_bm25.csv',index=False)


# In[ ]:




